Upload classifiers model to a static webserver
