package com.adrian.bernardez.apiElasticSearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiElasticSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
