package com.adrian.bernardez.apiElasticSearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiElasticSearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiElasticSearchApplication.class, args);
	}

}
